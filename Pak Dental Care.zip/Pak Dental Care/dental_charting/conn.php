<?php
$conn=mysqli_connect("localhost", "root", "", "dental_charting") or die("Error");
?>